"""
AdminPortal API Test Runner
======================================================
HOW TO RUN:
  Step 1: Start Flask server
          d:\\project\\backend\\venv\\Scripts\\python.exe d:\\project\\backend\\app.py

  Step 2: In a new terminal, run tests
          d:\\project\\backend\\venv\\Scripts\\python.exe d:\\project\\api-testing\\test_apis.py

  Or use py shortcut:
          py d:\\project\\api-testing\\test_apis.py
======================================================
"""

import urllib.request, urllib.error, json, sys
sys.stdout.reconfigure(encoding='utf-8')

BASE = "http://localhost:5000"
results = []

# ── Helpers ─────────────────────────────────────────────────
def req(method, path, body=None):
    data = json.dumps(body).encode() if body is not None else None
    hdrs = {"Content-Type": "application/json"} if data else {}
    r = urllib.request.Request(BASE + path, data=data, headers=hdrs, method=method)
    try:
        with urllib.request.urlopen(r) as res:
            return res.status, json.loads(res.read())
    except urllib.error.HTTPError as e:
        raw = e.read()
        try:    return e.code, json.loads(raw) if raw.strip() else {}
        except: return e.code, {}

def test(name, status, data, expect_code, check_fn=None):
    ok = (status == expect_code) and (check_fn(data) if check_fn else True)
    results.append(ok)
    tag = "[ PASS ]" if ok else "[ FAIL ]"
    print(f"  {tag}  {name}  [{status}]")
    if not ok:
        print(f"           Expected {expect_code}, got {status}")
        print(f"           Response: {data}")
    return data

print("\n" + "="*60)
print("  AdminPortal API Test Runner  |  http://localhost:5000")
print("="*60)

# ── 1. HEALTH ────────────────────────────────────────────────
print("\n[1] Health Check")
s, d = req("GET", "/health")
test("GET /health -> 200 OK", s, d, 200, lambda x: x.get("connected") == True)
test("user_count >= 1", s, d, 200, lambda x: x.get("user_count", 0) >= 1)

# ── 2. LOGIN ─────────────────────────────────────────────────
print("\n[2] Login")
s, d = req("POST", "/api/auth/login", {"email": "truptilakshmi.tm@gmail.com", "password": "trupti@2005"})
test("Valid login -> 200 + role=Super Admin", s, d, 200, lambda x: x.get("role") == "Super Admin")

s, d = req("POST", "/api/auth/login", {"email": "alice@gmail.com", "password": "wrongpass"})
test("Wrong password -> 401", s, d, 401)

s, d = req("POST", "/api/auth/login", {"password": "abc"})
test("Missing email -> 400", s, d, 400)

# Cleanup stale temp users from previous runs before creating them
_s2, _all2 = req("GET", "/api/users")
if _s2 == 200:
    _temp_stale = [u["id"] for u in _all2 if u.get("email") in {"inactive.test@x.com", "pending.test@x.com"}]
    if _temp_stale:
        req("POST", "/api/users/bulk-delete", {"ids": _temp_stale})

# Create a temp inactive user and test
s, d = req("POST", "/api/users", {"name": "Temp Inactive", "email": "inactive.test@x.com",
           "role": "Viewer", "status": "Inactive", "dept": "Testing"})
temp_inactive_id = d.get("id") if s == 201 else None

s, d = req("POST", "/api/auth/login", {"email": "inactive.test@x.com", "password": "password123"})
test("Inactive account -> 403", s, d, 403)

# Create a temp pending user and test
s, d = req("POST", "/api/auth/register", {"name": "Pending Temp", "email": "pending.test@x.com", "password": "pass123"})
temp_pending_id = d.get("user", {}).get("id") if s == 201 else None

s, d = req("POST", "/api/auth/login", {"email": "pending.test@x.com", "password": "pass123"})
test("Pending account -> 403", s, d, 403)

# ── 3. REGISTER ──────────────────────────────────────────────
print("\n[3] Register")

# Cleanup: delete any leftover test emails from previous runs so register always starts fresh
_CLEANUP_EMAILS = {"testuser_run99@example.com", "shortpwd99@example.com", "pending.test@x.com", "inactive.test@x.com"}
_s, _all = req("GET", "/api/users")
if _s == 200:
    _stale_ids = [u["id"] for u in _all if u.get("email") in _CLEANUP_EMAILS]
    if _stale_ids:
        req("POST", "/api/users/bulk-delete", {"ids": _stale_ids})

s, d = req("POST", "/api/auth/register",
           {"name": "Test User", "email": "testuser_run99@example.com", "password": "pass123", "dept": "HR"})
reg_id = d.get("user", {}).get("id") if s == 201 else None
test("Valid register -> 201 + status=Pending", s, d, 201,
     lambda x: x.get("user", {}).get("status") == "Pending")

s, d = req("POST", "/api/auth/register",
           {"name": "Dup", "email": "testuser_run99@example.com", "password": "pass123"})
test("Duplicate email -> 400", s, d, 400)

s, d = req("POST", "/api/auth/register",
           {"name": "Short", "email": "shortpwd99@example.com", "password": "123"})
test("Short password (< 6 chars) -> 400", s, d, 400)

s, d = req("POST", "/api/auth/register", {"name": "NoEmailUser"})
test("Missing email + password -> 400", s, d, 400)

# ── 4. GET ALL USERS ─────────────────────────────────────────
print("\n[4] Get All Users")
s, d = req("GET", "/api/users")
test("GET /api/users -> 200 + array", s, d, 200,
     lambda x: isinstance(x, list) and len(x) >= 1)
test("Each user has all required fields", s, d, 200,
     lambda x: all(k in x[0] for k in ["id","name","email","role","status","joined","avatar","dept"]) if x else False)

# ── 5. CREATE USER ───────────────────────────────────────────
print("\n[5] Create User")
# Cleanup stale create-user test email from previous runs
_s3, _all3 = req("GET", "/api/users")
if _s3 == 200:
    _cu_stale = [u["id"] for u in _all3 if u.get("email") == "priya.runner99@company.com"]
    if _cu_stale:
        req("POST", "/api/users/bulk-delete", {"ids": _cu_stale})

s, d = req("POST", "/api/users",
           {"name": "Priya Sharma", "email": "priya.runner99@company.com",
            "role": "Editor", "status": "Active", "dept": "Marketing"})
new_id = d.get("id") if s == 201 else None
test("Valid create -> 201", s, d, 201)
test("Auto avatar = PS", s, d, 201, lambda x: x.get("avatar") == "PS")

s, d = req("POST", "/api/users", {"name": "Dup", "email": "priya.runner99@company.com"})
test("Duplicate email -> 400", s, d, 400)

s, d = req("POST", "/api/users", {"email": "noname@example.com"})
test("Missing name -> 400", s, d, 400)

# ── 6. UPDATE USER ───────────────────────────────────────────
print("\n[6] Update User")
if new_id:
    s, d = req("PUT", f"/api/users/{new_id}", {"role": "Super Admin", "dept": "Leadership"})
    test(f"Valid update (id={new_id}) -> 200", s, d, 200,
         lambda x: x.get("role") == "Super Admin" and x.get("dept") == "Leadership")
else:
    print("  [SKIP]  Update (create user failed)")

s, d = req("PUT", "/api/users/99999", {"role": "Viewer"})
test("Update non-existent user -> 404", s, d, 404)

# ── 7. DELETE USER ───────────────────────────────────────────
print("\n[7] Delete User")
if new_id:
    s, d = req("DELETE", f"/api/users/{new_id}")
    test(f"Valid delete (id={new_id}) -> 200", s, d, 200)
    # Verify it's gone
    s2, _ = req("DELETE", f"/api/users/{new_id}")
    test(f"Delete again (already deleted) -> 404", s2, _, 404)
else:
    print("  [SKIP]  Delete (create user failed)")

s, d = req("DELETE", "/api/users/99999")
test("Delete non-existent -> 404", s, d, 404)

# ── 8. BULK DELETE ───────────────────────────────────────────
print("\n[8] Bulk Delete")
ids_to_delete = [x for x in [reg_id, temp_inactive_id, temp_pending_id] if x]
if ids_to_delete:
    s, d = req("POST", "/api/users/bulk-delete", {"ids": ids_to_delete})
    test(f"Bulk delete {ids_to_delete} -> 200", s, d, 200,
         lambda x: "deleted" in x.get("message", ""))
else:
    print("  [SKIP]  Bulk delete (no temp users)")

s, d = req("POST", "/api/users/bulk-delete", {"ids": []})
test("Empty ids array -> 400", s, d, 400)

s, d = req("POST", "/api/users/bulk-delete", {"ids": [99999, 99998]})
test("Non-existent IDs -> 200 (0 deleted)", s, d, 200,
     lambda x: "0 users deleted" in x.get("message", ""))

# ── SUMMARY ─────────────────────────────────────────────────
passed = sum(results)
total  = len(results)
print("\n" + "="*60)
print(f"  RESULTS: {passed}/{total} tests passed")
if passed == total:
    print("  All tests PASSED!")
else:
    print(f"  {total - passed} test(s) FAILED!")
print("="*60 + "\n")
sys.exit(0 if passed == total else 1)
